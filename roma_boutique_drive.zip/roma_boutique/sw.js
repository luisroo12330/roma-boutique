/* ROMA 1.0.1: migración desde la caché histórica.
   Los archivos web de la APK deben servirse desde la versión recién instalada.
   No eliminar localStorage, IndexedDB ni datos del usuario. */
self.addEventListener('install',event=>{event.waitUntil(self.skipWaiting())});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const names=await caches.keys();
    await Promise.all(names.filter(name=>name.startsWith('roma-boutique-')).map(name=>caches.delete(name)));
    await self.clients.claim();
    // En páginas de ROMA abiertas con el worker anterior, cargar el HTML nuevo.
    const clients=await self.clients.matchAll({type:'window',includeUncontrolled:true});
    await Promise.all(clients.map(async client=>{
      try{
        const address=new URL(client.url);
        if(address.origin===self.location.origin)await client.navigate(client.url);
      }catch(error){/* El usuario puede volver a abrir ROMA normalmente. */}
    }));
  })());
});
// Sin fetch cache-first: los recursos provienen del paquete Android actualizado.

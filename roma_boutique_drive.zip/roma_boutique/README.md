# ROMA — Interfaz 1.2

Código web de ROMA para empaquetar mediante Capacitor y GitHub Actions.

## Funciones
- Clientes, ventas a crédito, deudas, pagos, fotos y comprobantes.
- WhatsApp manual y notificaciones locales Android.
- Tasa Binance P2P VES, con entrada manual alternativa en Ajustes.
- Modo claro y oscuro; ajustes visuales de versión 1.2.
- Integración de Google Drive para iniciar sesión, guardar y restaurar copias según permisos y conectividad.

**Atención:** el selector de periodicidad de Google Drive guarda una preferencia, pero la programación automática en segundo plano todavía no está implementada. Verifica el funcionamiento real de Google Drive antes de depender de esos respaldos.

## Compilación
Sube este ZIP como `roma_boutique_drive.zip` y la configuración adjunta como `.github/workflows/build-apk.yml`. La compilación fija `versionName` en `1.2` y mantiene `versionCode` progresivo según el número de ejecución de GitHub Actions, la firma de release guardada en Secrets y el ID `com.romaboutique.app`.

## Búsquedas y navegación 1.2
- Lupa y barra animada independientes en Ventas, Clientes, Deudas, Historial y Pagadas. Cerrar la lupa limpia el filtro; Escape también la cierra.
- Búsqueda sin distinguir mayúsculas ni acentos. Las ventas permiten buscar cliente, teléfono, descripción, fechas, estado e importes; Pagadas incluye nombres de comprobantes.
- Historial conserva los registros y fotos y omite únicamente Editar venta y Eliminar venta; ambas acciones se mantienen en las demás vistas de ventas.
- Ventas muestra únicamente ventas con saldo pendiente. Pagadas muestra las ventas saldadas y sus fotos, abonos y comprobantes, incluso ventas saldadas con el pago inicial. Se conserva además una sección desplegable para consultar todos los abonos anteriores. La clasificación es por venta: un cliente puede tener ventas pendientes y pagadas.
- No se modifican almacenamiento, paquete, firma ni configuración de compilación. El workflow existente de ROMA 1.2 no requiere cambios.

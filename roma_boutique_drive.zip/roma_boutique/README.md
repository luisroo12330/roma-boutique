# ROMA — Interfaz 1.0

Código web de ROMA para empaquetar mediante Capacitor y GitHub Actions.

## Funciones
- Clientes, ventas a crédito, deudas, pagos, fotos y comprobantes.
- WhatsApp manual y notificaciones locales Android.
- Tasa Binance P2P VES, con entrada manual alternativa en Ajustes.
- Modo claro y oscuro; ajustes visuales de versión 1.0.
- Integración de Google Drive para iniciar sesión, guardar y restaurar copias según permisos y conectividad.

**Atención:** el selector de periodicidad de Google Drive guarda una preferencia, pero la programación automática en segundo plano todavía no está implementada. Verifica el funcionamiento real de Google Drive antes de depender de esos respaldos.

## Compilación
Sube este ZIP como `roma_boutique_drive.zip` y la configuración adjunta como `.github/workflows/build-apk.yml`. La compilación fija `versionName` en `1.0.0` y mantiene `versionCode` progresivo según el número de ejecución de GitHub Actions, la firma de release guardada en Secrets y el ID `com.romaboutique.app`.

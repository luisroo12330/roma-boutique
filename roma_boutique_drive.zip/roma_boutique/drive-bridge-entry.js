import { GoogleSignIn } from '@capawesome/capacitor-google-sign-in';

const WEB_CLIENT_ID = '497749754860-mlvfc55alarb6dv3suea17d08knoe2v5.apps.googleusercontent.com';
const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file';
const EMAIL_SCOPE = 'https://www.googleapis.com/auth/userinfo.email';
const FOLDER_NAME = 'ROMA BOUTIQUE';
let initialized = false;
let accessToken = null;
let selectedEmail = null;

async function init() {
  if (initialized) return;
  await GoogleSignIn.initialize({ clientId: WEB_CLIENT_ID, scopes: [DRIVE_SCOPE, EMAIL_SCOPE] });
  initialized = true;
}
async function authorize() {
  await init();
  const result = await GoogleSignIn.signIn();
  if (!result?.accessToken) throw new Error('Google no devolvió permiso de acceso a Drive.');
  accessToken = result.accessToken;
  selectedEmail = result.email || localStorage.getItem('romaDrive.email.v1') || 'Cuenta de Google';
  if (result.email) localStorage.setItem('romaDrive.email.v1', result.email);
  return { email: selectedEmail };
}
async function api(url, options = {}, retry = true) {
  if (!accessToken) await authorize();
  const headers = new Headers(options.headers || {});
  headers.set('Authorization', `Bearer ${accessToken}`);
  const response = await fetch(url, { ...options, headers });
  if (response.status === 401 && retry) {
    accessToken = null;
    await authorize();
    return api(url, options, false);
  }
  if (!response.ok) {
    const detail = await response.text().catch(() => '');
    throw new Error(`Google Drive respondió ${response.status}. ${detail.slice(0, 250)}`);
  }
  return response;
}
async function ensureFolder() {
  const q = encodeURIComponent(`name='${FOLDER_NAME}' and mimeType='application/vnd.google-apps.folder' and trashed=false`);
  const list = await (await api(`https://www.googleapis.com/drive/v3/files?q=${q}&spaces=drive&fields=files(id,name)&pageSize=100`)).json();
  if (list.files?.length) return list.files[0].id;
  const created = await (await api('https://www.googleapis.com/drive/v3/files?fields=id,name', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: FOLDER_NAME, mimeType: 'application/vnd.google-apps.folder' })
  })).json();
  return created.id;
}
async function backup(payload) {
  if (!accessToken) await authorize();
  const folderId = await ensureFolder();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const name = `ROMA-respaldo-${stamp}.json`;
  const metadata = { name, mimeType: 'application/json', parents: [folderId] };
  const boundary = 'roma_backup_boundary_2026';
  const body = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}\r\n--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(payload)}\r\n--${boundary}--`;
  const result = await (await api('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,createdTime', {
    method: 'POST', headers: { 'Content-Type': `multipart/related; boundary=${boundary}` }, body
  })).json();
  return result;
}
async function restore() {
  if (!accessToken) await authorize();
  const folderId = await ensureFolder();
  const q = encodeURIComponent(`'${folderId}' in parents and trashed=false`);
  const list = await (await api(`https://www.googleapis.com/drive/v3/files?q=${q}&orderBy=createdTime desc&pageSize=50&fields=files(id,name,createdTime,mimeType)`)).json();
  const backups = (list.files || []).filter(f => f.name?.startsWith('ROMA-respaldo-') && f.mimeType !== 'application/vnd.google-apps.folder');
  if (!backups.length) throw new Error('No hay copias de ROMA en la carpeta ROMA BOUTIQUE.');
  const file = backups[0];
  const data = await (await api(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(file.id)}?alt=media`)).json();
  if (data.app !== 'ROMA BOUTIQUE' || !data.db || !Array.isArray(data.db.clients) || !Array.isArray(data.db.sales) || !Array.isArray(data.db.payments)) throw new Error('El archivo más reciente no es una copia válida de ROMA.');
  return data;
}
window.ROMADrive = { connect: authorize, backup, restore };

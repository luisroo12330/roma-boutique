# ROMA BOUTIQUE — versión 0.1 Alpha

Esta es una primera versión web instalable (PWA) para probar el flujo principal en Android.

## Incluye
- Alta de clientes y teléfono en formato internacional con código de país.
- Ventas a crédito con descripción, foto, total, abono inicial y fecha de vencimiento.
- Registro de abonos y cálculo de saldo.
- Resumen de cuentas, atrasos e historial.
- Botón WhatsApp que abre `wa.me` con un mensaje preparado; el usuario revisa y pulsa Enviar.
- Tasa de cambio Binance P2P (venta) para VES y cálculo del equivalente en bolívares del saldo en dólares. El mensaje dice “Tasa de cambio Binance”, sin mencionar el activo digital.
- Opción de guardar una tasa manual si Binance no responde desde el navegador/dispositivo.
- Exportación e importación manual de copia de seguridad JSON.
- Datos guardados localmente en el navegador del dispositivo.

## Probar en Android
1. Descomprime el ZIP en una computadora o publica esta carpeta en un hosting HTTPS.
2. Abre la dirección HTTPS con Chrome en Android.
3. Usa el menú de Chrome → **Añadir a pantalla de inicio** o **Instalar aplicación**.

## Tasa Binance y cálculo en bolívares
La app intenta consultar anuncios P2P de Binance para VES usando el lado de venta y calcula una mediana de hasta 10 anuncios de comerciantes para reducir el efecto de precios extremos. El endpoint puede cambiar, limitar solicitudes o bloquear peticiones desde el navegador por CORS/red; por eso se incluye una tasa manual de respaldo. La tasa guardada muestra su hora de actualización. Antes de cobrar, verifica que la tasa sea la que deseas aplicar.

## Importante: límites de esta versión
- Esto todavía **no es un APK nativo compilado**. Es una PWA de prototipo; el ZIP contiene el código fuente.
- Para empaquetarla como APK se necesita un proyecto Android/Capacitor y compilarlo con Android SDK/Gradle.
- Los datos permanecen en el almacenamiento del navegador. Desinstalar, borrar datos o cambiar de navegador puede hacer que se pierdan; exporta copias de seguridad.
- La revisión de vencimientos de esta versión ocurre al abrir la app. No garantiza alarmas puntuales cuando la app está cerrada. Para recordatorios Android fiables hay que añadir AlarmManager/WorkManager y probar permisos/batería.
- La apertura de WhatsApp es manual. No se envía nada sin que el usuario confirme.
- Antes de uso real, probar exportación/restauración, validar teléfonos y añadir PIN/cifrado.

## Siguiente etapa recomendada
Convertir esta interfaz a una app Android con almacenamiento SQLite/Room, selector de fotos del sistema, notificaciones locales con WorkManager/AlarmManager, bloqueo PIN opcional y enlaces `wa.me`.


## Próximo paso para APK Android
Este ZIP sigue siendo el código fuente de la PWA, no un APK compilado. Para entregar una APK instalable hay que empaquetar la app con Capacitor en un proyecto Android y compilarla con Android Studio/Android SDK. En Android conviene implementar la consulta de Binance mediante una capa nativa o servicio intermedio para evitar problemas de CORS, y probarla con la versión real de Binance.


## Ajuste visual del encabezado
Se conservaron el fondo, los colores y la tipografía originales. Las etiquetas CLIENTES, VENTAS y CUENTAS PENDIENTES del subtítulo ahora tienen contornos finos y esquinas redondeadas, sin sombras ni efectos adicionales.

## Ajustes, apariencia y Google Drive
Se añadió una sección Ajustes dentro de la navegación. La exportación/restauración manual de JSON ya no aparece en la pantalla principal: está dentro de Ajustes. El modo claro/oscuro funciona y conserva la elección localmente. También se agregó la selección de frecuencia deseada para copias en Google Drive.

**Importante:** el respaldo automático real en Google Drive aún no está activo en esta versión web. Requiere integrar inicio de sesión OAuth de Google, acceso a Drive (preferiblemente al espacio privado `appDataFolder`) y una tarea periódica Android con WorkManager en la APK. La frecuencia elegida actualmente se guarda como preferencia, pero no inicia cargas a Drive. No se debe presentar como respaldo automático hasta completar y probar esa integración.


## Acceso rápido a Ajustes
El acceso a Ajustes ahora es un engranaje discreto en la esquina superior derecha del encabezado. Se retiró el botón Ajustes de la navegación inferior para mantener la pantalla despejada.


## Versión 0.1 Alpha
- La tasa Binance ahora aparece únicamente dentro de Ajustes.
- Etiqueta visible de versión: 0.1 Alpha.
- La integración real de Google Sign-In y Google Drive sigue pendiente de configurar credenciales OAuth y el componente Android de copias periódicas; no se anuncia como activa hasta completar y probar esa integración.


## Actualización de interfaz y pagos (0.2 Alpha)
- Se restauró el encabezado tipográfico ROMA BOUTIQUE sin el logotipo grande.
- Se ajustaron tamaños, márgenes, navegación y formularios para pantallas pequeñas.
- Se agregó la pestaña Pagos con historial de abonos y adjuntos de comprobantes en imagen o PDF. Las imágenes se comprimen antes de guardarse localmente.
- Los avisos web siguen dependiendo de que la aplicación esté abierta; las alarmas confiables en segundo plano requieren integración con Android nativo.
